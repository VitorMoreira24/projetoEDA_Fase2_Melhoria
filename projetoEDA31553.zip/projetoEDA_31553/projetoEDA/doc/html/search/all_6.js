var searchData=
[
  ['nefastos_0',['nefastos',['../structnefastos.html',1,'nefastos'],['../antenas_8h.html#af028b1925f18aeb20b13b5fec01807df',1,'nefastos:&#160;antenas.h']]]
];
