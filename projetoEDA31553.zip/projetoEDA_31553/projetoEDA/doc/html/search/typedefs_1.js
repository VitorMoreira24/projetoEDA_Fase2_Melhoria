var searchData=
[
  ['nefastos_0',['nefastos',['../antenas_8h.html#af028b1925f18aeb20b13b5fec01807df',1,'antenas.h']]]
];
