var searchData=
[
  ['calcularnefastos_0',['calcularnefastos',['../antenas_8c.html#a227673583dc103cd0d4edd828ad37b60',1,'calcularNefastos(Antena *lista):&#160;antenas.c'],['../antenas_8h.html#a227673583dc103cd0d4edd828ad37b60',1,'calcularNefastos(Antena *lista):&#160;antenas.c']]],
  ['carregarantenasdoficheiro_1',['carregarantenasdoficheiro',['../antenas_8c.html#a6712a3faa6702e6373561a397f1809b7',1,'CarregarAntenasDoFicheiro(const char *nome_ficheiro):&#160;antenas.c'],['../antenas_8h.html#a6712a3faa6702e6373561a397f1809b7',1,'CarregarAntenasDoFicheiro(const char *nome_ficheiro):&#160;antenas.c']]],
  ['compilação_20do_20programa_2',['Compilação do Programa',['../md__2home_2vitor_2Desktop_2projetoEDA_2projetoEDA_2README.html#autotoc_md3',1,'']]],
  ['criaantena_3',['criaantena',['../antenas_8c.html#a0a7c36c80d5eb45c41a9f516434a7b51',1,'CriaAntena(char coluna, int linha, int freq):&#160;antenas.c'],['../antenas_8h.html#a0cddd59c73ccb91cdbfaf548746e0d9e',1,'CriaAntena(char frequencia, int linha, int coluna):&#160;antenas.c']]],
  ['criarefeitonefasto_4',['criarefeitonefasto',['../antenas_8c.html#ad2f7fe193467a02ce38d8583f394007d',1,'criarEfeitoNefasto(int x, int y):&#160;antenas.c'],['../antenas_8h.html#ad2f7fe193467a02ce38d8583f394007d',1,'criarEfeitoNefasto(int x, int y):&#160;antenas.c']]]
];
