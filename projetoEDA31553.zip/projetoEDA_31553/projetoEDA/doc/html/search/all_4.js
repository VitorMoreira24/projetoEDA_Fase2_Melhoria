var searchData=
[
  ['libertarlistanefasto_0',['libertarlistanefasto',['../antenas_8c.html#ac72d6ee151bdb904ac5e6704a4137aae',1,'libertarListaNefasto(nefastos *lnefasto):&#160;antenas.c'],['../antenas_8h.html#ac72d6ee151bdb904ac5e6704a4137aae',1,'libertarListaNefasto(nefastos *lnefasto):&#160;antenas.c']]]
];
