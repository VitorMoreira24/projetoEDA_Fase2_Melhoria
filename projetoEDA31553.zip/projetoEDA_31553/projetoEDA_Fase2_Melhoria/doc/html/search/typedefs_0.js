var searchData=
[
  ['adjacencia_0',['Adjacencia',['../antenas_8h.html#ad1a707f5a55de6e25322735fd69b8a96',1,'antenas.h']]],
  ['antena_1',['Antena',['../antenas_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2',1,'antenas.h']]]
];
