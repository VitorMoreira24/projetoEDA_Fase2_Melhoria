var searchData=
[
  ['caminhono_0',['caminhono',['../structCaminhoNo.html',1,'CaminhoNo'],['../antenas_8h.html#ab82c17f59f0ef3217d89de2c2f61e022',1,'CaminhoNo:&#160;antenas.h']]],
  ['carregarantenasdoficheiro_1',['carregarantenasdoficheiro',['../antenas_8h.html#a573fd35edaafc8db3a494e3c41ab1a61',1,'CarregarAntenasDoFicheiro(const char *nome_ficheiro):&#160;funcoes.c'],['../funcoes_8c.html#a4c87d13f1e63a821415e6921108504af',1,'CarregarAntenasDoFicheiro(const char *nomeFicheiro):&#160;funcoes.c']]]
];
