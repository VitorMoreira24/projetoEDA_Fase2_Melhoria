/*****************************************************************//**
 * \file   antenas.h
 * \brief  Ficheiro .h com todos os dados relacionados com as antenas
 * 
 * \author Vitor Moreira 31553
 * \date   30 de Mar�o 2025
 *********************************************************************/
#pragma once
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
 /*****************************************************************//**
  * \brief Struct que representa uma antena
  *
  * \param frequencia - Frequ�ncia da antena ex: 'A', 'B' , '.' , etc
  * \param linha - Linha da matrizes
  * \param coluna - Coluna da matriz
  * \param prox - Aponta para a pr�xima antena
  * 
  *********************************************************************/
typedef struct Antena {
    char frequencia;       // Ex: 'A', 'B'
    int linha, coluna;     // Posi��o na matriz
    struct Antena* prox;   // Pr�xima antena
} Antena;


/*****************************************************************//**
 * \brief Struct que representa nefastos
 *
 * \param x - Coordenada x
 * \param y - Coordenada y
 * \param prox - Aponta para o pr�ximo nefasto
 *********************************************************************/
typedef struct nefastos {
	int x, y;
	struct nefastos* prox;
}nefastos;

extern int MAX_COLUNAS;
extern int MAX_LINHAS;

// Prot�tipos das fun��es no ficheiro antenas.c
Antena* CriaAntena(char frequencia, int linha, int coluna);
Antena* InsereOrdenado(Antena* inicio, Antena* novo);
Antena* RemoveAntena(Antena* inicio, int linha, int coluna);
Antena* ProcuraAntena(Antena* inicio, int linha, int coluna);
Antena* CarregarAntenasDoFicheiro(const char* nome_ficheiro);
nefastos* criarEfeitoNefasto(int x, int y);
nefastos* calcularNefastos(Antena* lista);
void mostrarMatrizAntenas(Antena* lista);
void mostrarMatrizNefastos(Antena* lista_antenas, nefastos* lista_nefastos);
void libertarListaNefasto(nefastos* lnefasto);
//void DestroiListaAntenas(Antena** h);
