var searchData=
[
  ['nefastos_0',['nefastos',['../structnefastos.html',1,'']]]
];
