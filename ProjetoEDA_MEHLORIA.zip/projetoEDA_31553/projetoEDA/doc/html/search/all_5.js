var searchData=
[
  ['main_2ec_0',['main.c',['../main_8c.html',1,'']]],
  ['mostrarmatrizantenas_1',['mostrarmatrizantenas',['../antenas_8c.html#acd5150ac505a2e639de16a92b61980ac',1,'mostrarMatrizAntenas(Antena *lista):&#160;antenas.c'],['../antenas_8h.html#acd5150ac505a2e639de16a92b61980ac',1,'mostrarMatrizAntenas(Antena *lista):&#160;antenas.c']]],
  ['mostrarmatriznefastos_2',['mostrarmatriznefastos',['../antenas_8c.html#a58ee45e0f49c3964368bfa2f15aba4c5',1,'mostrarMatrizNefastos(Antena *lista_antenas, nefastos *lista_nefastos):&#160;antenas.c'],['../antenas_8h.html#a58ee45e0f49c3964368bfa2f15aba4c5',1,'mostrarMatrizNefastos(Antena *lista_antenas, nefastos *lista_nefastos):&#160;antenas.c']]]
];
