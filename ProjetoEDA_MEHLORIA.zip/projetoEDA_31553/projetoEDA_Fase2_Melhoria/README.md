# PROJETO_EDA FASE 2 MELHORIA

Licenciatura em Engenharia de Sistemas Informáticos 2024-25 (**pós-laboral**)

Laboratórios de Informática 

| Número | Nome |
| -----   | ---- |
|  31553     |  Vitor Moreira  |

## Organização

[projetoEDA/](./projetoEDA/)  Código da solução desenvolvida 

[doc/](.doc/)  documentação gerado pela ferramenta Doxygen

## Download do Projeto

Para aceder ao downlaod da fase 1 e 2, a partir do repositório GITHUB realizar o download do ficheiro "projetoEDA31553.zip"

## Compilação do Programa

Através do Visual Studio em primeira instância compilar o programa
