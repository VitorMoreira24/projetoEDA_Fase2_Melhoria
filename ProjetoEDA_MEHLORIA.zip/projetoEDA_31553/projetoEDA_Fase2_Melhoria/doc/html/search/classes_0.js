var searchData=
[
  ['adjacencia_0',['Adjacencia',['../structAdjacencia.html',1,'']]],
  ['antena_1',['Antena',['../structAntena.html',1,'']]]
];
