var searchData=
[
  ['adicionaradj_0',['adicionaradj',['../antenas_8h.html#ac46c75e7294c945af23d9da3e3b5a768',1,'AdicionarAdj(Antena *origem, Antena *destino):&#160;funcoes.c'],['../funcoes_8c.html#ac46c75e7294c945af23d9da3e3b5a768',1,'AdicionarAdj(Antena *origem, Antena *destino):&#160;funcoes.c']]],
  ['adicionarantena_1',['adicionarantena',['../antenas_8h.html#ad16278693879a2a9c2b3cb401bba4d36',1,'AdicionarAntena(Grafo *grafo, char freq, int col, int lin):&#160;funcoes.c'],['../funcoes_8c.html#ad16278693879a2a9c2b3cb401bba4d36',1,'AdicionarAntena(Grafo *grafo, char freq, int col, int lin):&#160;funcoes.c']]],
  ['adjacencia_2',['adjacencia',['../structAdjacencia.html',1,'Adjacencia'],['../antenas_8h.html#ad1a707f5a55de6e25322735fd69b8a96',1,'Adjacencia:&#160;antenas.h']]],
  ['antena_3',['antena',['../structAntena.html',1,'Antena'],['../antenas_8h.html#a843ab8b81393e8ebb3eb6b76e349acc2',1,'Antena:&#160;antenas.h']]],
  ['antenas_2eh_4',['antenas.h',['../antenas_8h.html',1,'']]]
];
