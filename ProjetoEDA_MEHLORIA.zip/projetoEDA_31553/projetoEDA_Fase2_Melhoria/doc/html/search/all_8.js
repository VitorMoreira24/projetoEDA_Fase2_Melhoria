var searchData=
[
  ['resultados_0',['resultados',['../antenas_8h.html#a423e896035c9ec672061f9ead05292c2',1,'Resultados(Grafo grafo, const char *nome_ficheiro):&#160;funcoes.c'],['../funcoes_8c.html#acf0027806e310a01722e1182a6518978',1,'Resultados(Grafo grafo, const char *nomeFicheiro):&#160;funcoes.c']]]
];
