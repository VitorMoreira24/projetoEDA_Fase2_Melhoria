var searchData=
[
  ['main_0',['main',['../main_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['mostrarinterferencias_2',['mostrarinterferencias',['../antenas_8h.html#a7a2f033a77edbf2fb3971d2471bfea49',1,'MostrarInterferencias(Grafo *grafo, FILE *saida):&#160;funcoes.c'],['../funcoes_8c.html#a7a2f033a77edbf2fb3971d2471bfea49',1,'MostrarInterferencias(Grafo *grafo, FILE *saida):&#160;funcoes.c']]],
  ['mostrarintersecoes_3',['mostrarintersecoes',['../antenas_8h.html#a86286bb4f2de0e99bbd66dc24d04a139',1,'MostrarIntersecoes(Grafo *grafo, char freqA, char freqB, FILE *saida):&#160;funcoes.c'],['../funcoes_8c.html#a86286bb4f2de0e99bbd66dc24d04a139',1,'MostrarIntersecoes(Grafo *grafo, char freqA, char freqB, FILE *saida):&#160;funcoes.c']]]
];
